// /* standard 16x9 resolutions
// 2160p: 3840×2160
// 1440p: 2560×1440
// 1080p: 1920×1080
// 720p: 1280×720
// 480p: 854×480
// 360p: 640×360
// 240p: 426×240
// */

// these values based on camera input that is 1920x1080, adjust for your camera
let capture;
let scaleValue = 41;
let videoWidth = 640;
let videoHeight = 480;
let appWidth = 570;
let appHeight = 570;

// 15x15

function setup() {
  createCanvas(appWidth, appHeight);
  //  https://p5js.org/examples/dom-video-capture.html
  // capture = createCapture(VIDEO);
  capture = createVideo("video/Comp 2.mp4");
  capture.size(videoWidth / scaleValue, videoHeight / scaleValue);

  console.log(videoWidth / scaleValue, videoHeight / scaleValue)
  capture.loop();
  // capture.hide();
  // https://p5js.org/reference/#/p5/pixelDensity
  pixelDensity(1);
  rectMode(CENTER);
  // noStroke();
}

function drawRetangles(color, xpos, ypos, pixelSize) {
  fill(color);
  rect(
    xpos,
    ypos,
    pixelSize, // (pixelSize * capture.pixels[offset] + 0) / 255,
    pixelSize // (pixelSize * capture.pixels[offset] + 1) / 255
  );
}

function draw() {
  // background(255);
  // fill(255);

  // https://p5js.org/reference/#/p5.Image/loadPixels
  //https:www.youtube.com/watch?v=nMUMZ5YRxHI
  capture.loadPixels();

  let pixelSize = 38;

  // grid make grid size big or small
  // let gridSize = 1;
  let gridSize = 1;
  for (let captureY = 0; captureY < capture.height; captureY += gridSize) {
    for (let captureX = 0; captureX < capture.width; captureX += gridSize) {
      //console.log("cap x,y", captureX, captureY);
      // https://p5js.org/reference/#/p5/pixels
      let offset = (captureY * capture.width + captureX) * 4;
      let xpos = (captureX / capture.width) * appWidth;
      let ypos = (captureY / capture.height) * appHeight;
     

      // console.log(xpos, ypos)

      // greyscale by averaging the rgb values
      let r = capture.pixels[offset];
      let g = capture.pixels[offset + 1];
      let b = capture.pixels[offset + 2];
      let a = capture.pixels[offset + 3];

      let c = color(
        capture.pixels[offset],
        capture.pixels[offset + 1],
        capture.pixels[offset + 2],
        capture.pixels[offset + 3]
      );

      let brightness = (r + g + b) / 3;
      let hsbValue = map(brightness, 0, 255, 0, 360);

      // uncomment line 128 to draw greyscale
      drawRetangles(c, xpos, ypos, pixelSize);
    }
  }
}
